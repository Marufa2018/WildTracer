package com.example.android.walkmyandroid;

import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.view.View;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedList;
import java.util.Scanner;

public class NewLocation extends AppCompatActivity {
    private final LinkedList<String> mWordList = new LinkedList<>();
    File sdcard = Environment.getExternalStorageDirectory();

    File file = new File(sdcard,"D:\\file.txt");

    //Read text from file
    StringBuilder text = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_loc);

        TextView myTextView = findViewById(R.id.textview_location);

                // A string variable to store the text from the text file
        String myOutput;

        // Declaring an input stream to read data

        InputStream myInputStream;

        // Put initial data into the word list.
      //  for (int i = 0; i < 20; i++) {
          //  mWordList.addLast("Word " + i);
      //  }

        try {
            Scanner in = new Scanner(file);
            String line;

            while ((line = in.nextLine()) != null) {
                text.append(line);
                text.append('\n');
            }
            in.close();
        }
        catch (IOException e) {
            //You'll need to add proper error handling here
        }

        myTextView.setText(text);
    }

    public void sendsms(View view) {
    }
}
