package com.example.android.walkmyandroid;

import android.os.Bundle;
import android.os.Environment;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedList;

public class ChooseLocation extends AppCompatActivity {

    private final LinkedList<String> mWordList = new LinkedList<>();

    File sdcard = Environment.getExternalStorageDirectory();

    File file = new File(sdcard,"D:\\file.txt");

    //Read text from file
    StringBuilder text = new StringBuilder();

    private RecyclerView mRecyclerView;
    private com.example.android.walkmyandroid.WordListAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.choose_location);

       /* InputStream myInputStream;

        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;

            while ((line = br.readLine()) != null) {
                text.append(line);
                text.append('\n');
            }
            br.close();
        }
        catch (IOException e) {
            //You'll need to add proper error handling here
        }
*/
        // Put initial data into the word list.
        for (int i = 0; i < 20; i++) {
            mWordList.addLast("আমার জায়গা" + i);
        }

        // Create recycler view.
        mRecyclerView = findViewById(R.id.recyclerview);
        // Create an adapter and supply the data to be displayed.
        mAdapter = new com.example.android.walkmyandroid.WordListAdapter(this, mWordList);
        // Connect the adapter with the recycler view.
        mRecyclerView.setAdapter(mAdapter);
        // Give the recycler view a default layout manager.
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
    }


}

