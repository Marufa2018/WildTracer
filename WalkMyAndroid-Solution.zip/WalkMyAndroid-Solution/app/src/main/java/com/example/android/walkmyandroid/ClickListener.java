package com.example.android.walkmyandroid;

public interface ClickListener {
    void onPositionClicked(int position);

    void onLongClicked(int position);
}
